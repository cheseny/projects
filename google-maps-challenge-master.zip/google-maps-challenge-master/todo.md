# Plan Of Action

- Create Wireframe DONE

- Set Up the base HTML structure  DONE

- Import Google Maps into the window DONE

- Add the text Store Locator DONE

- Add input box DONE

- Add Store List Container DONE

- Add individual store container 


